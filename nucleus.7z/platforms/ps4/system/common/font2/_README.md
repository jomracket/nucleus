Following files have to be present in this folder. Please, extract these firmware files from the folder `/system/common/font2` of your own legally purchased console.

```
SCE-RDC-B-JPN.otf
SCE-RDC-R-JPN.otf
```
